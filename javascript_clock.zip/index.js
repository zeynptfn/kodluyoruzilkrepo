document.getElementById("submitName").addEventListener("click", function() {
    // Kullanıcının adını al
    let userName = document.getElementById("nameInput").value;

    // Eğer kullanıcı bir ad girmemişse, uyarı ver
    if (!userName) {
        alert("Lütfen isminizi giriniz!");
        return;
    }

    // Karşılama mesajını ayarla
    document.getElementById("welcomeMessage").innerText = "Hoş geldin, " + userName + "!";

    // Geçerli tarih ve saati al ve ekrana yazdır
    let currentDateTime = new Date();
    let day = currentDateTime.toLocaleString('tr-TR', { weekday: 'long' });
    let time = currentDateTime.toLocaleTimeString('tr-TR');
    let date = currentDateTime.toLocaleDateString('tr-TR');

    document.getElementById("currentDateTime").innerText = "Bugün günlerden " + day + " ve saat: " + time + " - Tarih: " + date;

    // Giriş ekranını gizle ve karşılama ekranını göster
    document.getElementById("nameInputSection").style.display = "none";
    document.getElementById("welcomeSection").style.display = "block";
});
